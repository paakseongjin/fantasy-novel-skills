# 판단이 갈리는 조합

- **“초반이 지루하대. 원인을 알려 줘.”** 초반 목표·정보 부담이 쟁점이면 `lower-opening-barrier`, 쟁점이 불명확하면 `review-fantasy-manuscript`. 여러 구간의 이탈 위험을 비교해 달라면 `audit-dropout-risks`. 선택한 스킬이 찾은 같은 근거는 재수집을 생략한다.
- **“다음 화를 구성하고 본문만 줘.”** `structure-serial-chapters`로 목표·장면 변화·끝 상태를 내부에서 잡고 `write-fantasy-prose`로 완성한다. 직전 종료 상태가 없고 회차 연결에 필수라면 해당 부분만 요청한다.
- **“이 반전을 지금 밝혀도 설정이 맞아?”** `manage-fantasy-foreshadowing`에서 독자가 본 단서와 인물의 지식을 확인한다. 공개가 승인된 설정·확정 사건과 충돌할 수 있으면 그 근거만 `audit-fantasy-canon`으로 대조한다.
- **“갈등이 억지스럽고 두 사람의 말투도 같아.”** `write-character-conflict`에서 각자의 욕구·계기를 잡고 `craft-character-dialogue`에서 화법을 반영한다. 수정 요청이라면 두 변경을 본문 하나에 합친다.
- **“마법을 귀족 사회에 연결해 줘.”** `build-fantasy-world`에서 마법의 조건을 먼저 잡고, 그 조건에 따라 자원과 권한을 누가 갖는지 설계한다. 마법과 작위가 이미 고정됐으면 두 규칙이 맞물리는 부분만 본다.
