---
name: design-fantasy-religions
description: 판타지 신의 실재, 교리와 의례, 분파, 성직 조직과 정치 권력을 설계한다.
---

# 종교와 의례

신의 실제 개입과 신도가 믿는 교리를 구별한다. 누가 기적을 판정하고 의례에 접근하며 그 권한을 두고 무엇을 다투는지 정한다.

기존 확정 조건을 유지하고 추가 내용은 제안으로 표시한다.
상세 설계는 [분야 지침](references/religions-guide.md), 사례가 필요하면 [예시](references/religions-examples.md)의 관련 절을 사용한다.
복합 설계는 [공통 규칙](references/common.md), 근거 확인은 [출처](references/sources.md)를 필요할 때 참고한다.
