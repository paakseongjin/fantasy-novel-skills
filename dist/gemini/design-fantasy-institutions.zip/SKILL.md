---
name: design-fantasy-institutions
description: 판타지 신분·작위·관직·군 계급의 승계·임명·지휘권·호칭을 설계한다.
---

# 신분과 조직 권한

작위·직책·지휘권을 분리해 누가 누구를 어떤 상황에서 명령하거나 해임할 수 있는지 정한다. 권한이 겹치면 실제 분쟁을 결정할 판정권자를 둔다.

기존 확정 조건을 유지하고 추가 내용은 제안으로 표시한다.
상세 설계는 [분야 지침](references/ranks-guide.md), 사례가 필요하면 [예시](references/ranks-examples.md)의 관련 절을 사용한다.
복합 설계는 [공통 규칙](references/common.md), 근거 확인은 [출처](references/sources.md)를 필요할 때 참고한다.
[장르 프리셋](references/genre-presets.md)은 기존 장르 규칙을 변형할 때 사용한다.
