---
name: name-fantasy-world
description: 판타지 인명·지명·조직명을 문화권의 어감과 명명 규칙에 맞춰 짓는다.
---

# 명칭과 조어

기존 명칭이 있으면 음절·어미·호칭 규칙을 따르고 가까운 이름끼리 잘 구분되는지 본다. 이름만 요청하면 요청한 수량을 제안한다.

기존 확정 조건을 유지하고 추가 내용은 제안으로 표시한다.
상세 설계는 [분야 지침](references/names-guide.md), 사례가 필요하면 [예시](references/names-examples.md)의 관련 절을 사용한다.
복합 설계는 [공통 규칙](references/common.md), 근거 확인은 [출처](references/sources.md)를 필요할 때 참고한다.
