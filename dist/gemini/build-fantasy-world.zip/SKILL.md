---
name: build-fantasy-world
description: 한국어 판타지의 지리·명칭·마법·제도·국가·종족·종교 중 필요한 설정을 만들고 여러 분야의 인과를 연결한다.
---

# 판타지 세계관 설계

작가가 확정한 조건을 잠그고 새 설정은 제안으로 다룬다. 짧은 요청은 해당 산출물만 답한다. 예를 들어 길드 이름을 요청하면 기존 명명 규칙과 어감을 맞춰 이름만 제안한다. 세부 규칙·설정 간 인과가 필요하면 아래에서 해당 분야의 지침을 읽고, 구체적 사례가 필요할 때만 관련 예시를 찾는다.

| 요청 분야 | 상세 지침 | 사례 |
|---|---|---|
| 지리·기후·역사 | [세계 골격](references/world-guide.md) | [지리·역사](references/world-examples.md) |
| 이름·조어·호칭 | [명칭](references/names-guide.md) | [작명](references/names-examples.md) |
| 마법·능력·유물 | [마법](references/magic-guide.md) | [능력·유물](references/magic-examples.md) |
| 작위·관직·조직 권한 | [제도](references/ranks-guide.md) | [서열·승계](references/ranks-examples.md) |
| 국가·도시·교역·외교 | [국가](references/nations-guide.md) | [경제·외교](references/nations-examples.md) |
| 종족·문화·생활 | [종족](references/peoples-guide.md) | [생리·문화](references/peoples-examples.md) |
| 신·교리·의례 | [종교](references/religions-guide.md) | [신앙·제도](references/religions-examples.md) |
| 분야 간 정합성·장면화 | [정합성](references/canon-guide.md) | [충돌·장면](references/canon-examples.md) |

새 규칙은 `발동 조건·제약 → 누가 이익이나 비용을 부담하는가 → 인물의 선택이 어떻게 달라지는가`로 구체화한다. 여러 분야가 관련되면 결과를 실제로 제한하는 규칙부터 확정하거나 제안한다. 예를 들어 저장할 수 없는 마력은 운송·독점 제도가 먼저 달라진다. 기존 설정 검토는 어긋나는 전제 또는 빠진 연결과 최소 변경안을 준다. 여러 안을 요청하면 작동 방식·대가가 다른 안을 제시한다.

복합 설계에만 [공통 규칙](references/common.md)의 관련 절을 참고한다. 익숙한 마법·작위 체계는 [장르 프리셋](references/genre-presets.md), 여러 분야를 이은 사례는 [연결 예제](references/connected-world.md), 설정집 요청은 [설정집 양식](references/world-bible-template.md), 근거 확인은 [출처](references/sources.md)를 사용한다. 예시의 사실과 명칭은 작품 정전에 자동 편입하지 않는다.

## Gemini Apps에서 적용

이 스킬에 업로드된 참고 파일 중 요청에 맞는 파일을 이름과 경로로 찾는다. 예시집의 설정은 창작 예시로 읽고, 인물의 상태는 이번 요청에서 확인한 작품 원고를 기준으로 판단한다. Drive 자료를 언급했지만 내용을 볼 수 없다면 판단에 필요한 구간만 요청한다.

한 요청에 여러 활성 스킬을 조합할 때에는 선택한 작업에 필요한 스킬을 이름으로 참조한다. 회차 구성과 집필을 함께 요청한 경우에는 구성에서 확정한 사건을 집필로 넘긴다. 공유받은 스킬에서 필요한 참고 파일을 열 수 없으면 어떤 파일이 필요한지 밝히고, 확인 가능한 원고로 진행한다.
