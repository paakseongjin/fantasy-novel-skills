---
name: design-fantasy-world
description: 판타지 세계의 지리·기후·연대기와 현재 갈등을 연결한다.
---

# 지리와 역사

무대나 역사 한 가지를 설계할 때 지형·자원·이동 조건 중 사건을 바꾸는 조건을 고른다. 그 조건이 생활 방식과 현재 갈등을 어떻게 만드는지 잇는다.

기존 확정 조건을 유지하고 추가 내용은 제안으로 표시한다.
상세 설계는 [분야 지침](references/world-guide.md), 사례가 필요하면 [예시](references/world-examples.md)의 관련 절을 사용한다.
복합 설계는 [공통 규칙](references/common.md), 근거 확인은 [출처](references/sources.md)를 필요할 때 참고한다.
[장르 프리셋](references/genre-presets.md)은 기존 장르 규칙을 변형할 때 사용한다.
[연결 예제](references/connected-world.md)는 분야 여러 개의 연결 사례가 필요할 때 사용한다.
[설정집 양식](references/world-bible-template.md)은 설정집 인계를 요청받았을 때 사용한다.
