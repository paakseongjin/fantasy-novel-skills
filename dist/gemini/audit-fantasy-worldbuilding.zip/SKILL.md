---
name: audit-fantasy-worldbuilding
description: 판타지 설정 분야 간 인과·규칙의 파급을 점검하고 설정을 행동·선택으로 장면화한다.
---

# 설정의 정합성과 장면화

설정 두 개가 어디에서 만나고 어떤 조건에서 서로를 제한하는지 추적한다. 누가 이익과 비용을 지는지 확인하고, 그 규칙이 선택을 바꾸는 장면이나 최소 변경을 제시한다.

기존 확정 조건을 유지하고 추가 내용은 제안으로 표시한다.
상세 설계는 [분야 지침](references/canon-guide.md), 사례가 필요하면 [예시](references/canon-examples.md)의 관련 절을 사용한다.
확정 원고와 정전의 회차별 대조는 `audit-fantasy-canon`의 범위다.
복합 설계는 [공통 규칙](references/common.md), 근거 확인은 [출처](references/sources.md)를 필요할 때 참고한다.
[연결 예제](references/connected-world.md)는 분야 여러 개의 연결 사례가 필요할 때 사용한다.
[설정집 양식](references/world-bible-template.md)은 설정집 인계를 요청받았을 때 사용한다.
