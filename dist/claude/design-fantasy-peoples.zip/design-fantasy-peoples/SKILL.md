---
name: design-fantasy-peoples
description: 판타지 종족의 생리·환경·생활과 집단 내부의 문화 차이를 설계한다.
---

# 종족과 문화

생리와 환경의 제약이 생활 방식에 끼치는 영향을 설명한다. 같은 종족도 지역·계층·제도에 따라 어떻게 다르게 대응하는지 보여 준다.

기존 확정 조건을 유지하고 추가 내용은 제안으로 표시한다.
상세 설계는 [분야 지침](references/peoples-guide.md), 사례가 필요하면 [예시](references/peoples-examples.md)의 관련 절을 사용한다.
복합 설계는 [공통 규칙](references/common.md), 근거 확인은 [출처](references/sources.md)를 필요할 때 참고한다.
