---
name: design-fantasy-magic
description: 판타지 마법·이능·유물의 발동 조건, 한계, 비용과 사회적 파급을 설계한다.
---

# 마법과 능력

누가 어떤 조건으로 무엇을 할 수 있는지, 대가를 누가 언제 치르는지 정한다. 강한 사용자가 비용을 우회하는 경우를 한 번 대조한다.

기존 확정 조건을 유지하고 추가 내용은 제안으로 표시한다.
상세 설계는 [분야 지침](references/magic-guide.md), 사례가 필요하면 [예시](references/magic-examples.md)의 관련 절을 사용한다.
복합 설계는 [공통 규칙](references/common.md), 근거 확인은 [출처](references/sources.md)를 필요할 때 참고한다.
[장르 프리셋](references/genre-presets.md)은 기존 장르 규칙을 변형할 때 사용한다.
