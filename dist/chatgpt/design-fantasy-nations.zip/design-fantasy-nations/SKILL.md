---
name: design-fantasy-nations
description: 판타지 국가·도시의 생계 자원·교역·행정·외교를 설계한다.
---

# 국가와 교역

필수 자원 한 가지의 공급처·운송·통제권을 따라간다. 공급이 끊기면 먼저 영향을 받는 집단과 그 집단이 취할 행동을 정한다.

기존 확정 조건을 유지하고 추가 내용은 제안으로 표시한다.
상세 설계는 [분야 지침](references/nations-guide.md), 사례가 필요하면 [예시](references/nations-examples.md)의 관련 절을 사용한다.
복합 설계는 [공통 규칙](references/common.md), 근거 확인은 [출처](references/sources.md)를 필요할 때 참고한다.
